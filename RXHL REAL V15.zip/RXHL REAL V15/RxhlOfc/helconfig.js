global.prefa = ['','!','.',',','🐤','🗿']
global.falown = "<!> `Kau siapa? Bukan dari Team Kami`"
global.falmurbug = "<!> `Bukan Murbug jir 🗿😂`"
global.inputnum = "<!> `MASUKAN NOMOR NYA`"
global.falgrup = "<!> `Fitur Ini Cuma Bisa Di Akses Di Dalam Group`"
global.imagemenu = ["https://pomf2.lain.la/f/cjdc9cvv.jpg", "https://files.catbox.moe/ifbth9.jpg", "https://pomf2.lain.la/f/cjdc9cvv.jpg", "https://pomf2.lain.la/f/cjdc9cvv.jpg", "https://pomf2.lain.la/f/cjdc9cvv.jpg", "https://pomf2.lain.la/f/cjdc9cvv.jpg", "https://pomf2.lain.la/f/cjdc9cvv.jpg"];

global.owner = [
  "6285194521357", //should start with country code
  "628567610818"  //second number if available
]


let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})